#ifndef __STMFLASH_H__
#define __STMFLASH_H__

#include "sys.h"
#include "usart3.h"
#include "delay.h"
#include "usart1.h"

#define STM32_FLASH_BASE        0x08000000      /* STM32 FLASH的起始地址 */
#define STM32_FLASH_SIZE        0x20000         /* STM32 FLASH总大小*/
#define BOOT_FLASH_SIZE         0x4000          /* 前16K FLASH用于保存BootLoader */
#define FLASH_WAITETIME         50000           /* FLASH等待超时时间 */

#define BANK1_FLASH_SECTOR_0    ((uint32_t)0x08000000)  /* Bank1扇区0起始地址, 128 Kbytes  */

uint32_t Stmflash_Read_Word(uint32_t faddr);    
void Stmflash_Write(uint32_t waddr, uint32_t *pbuf, uint32_t length);  
void Stmflash_Read(uint32_t raddr, uint32_t *pbuf, uint32_t length);   

void Test_Write(uint32_t waddr, uint32_t wdata);
    
#endif


