#ifndef _OPERATE_H
#define _OPERATE_H

#include "sys.h"
#include "xyz_move.h"
#include "delay.h"
#include "usart3.h"
#include "timer.h"
#include <stdlib.h>


#define MOVE  0
#define SEED  1
#define WATER 2
#define SD_WT 3

extern uint8_t Place_Array[16];
extern uint8_t Place_Axis_X[15];;
extern uint8_t Place_Axis_Y[15];;
extern uint8_t Target_Num;


void Mode_Operate_Process(uint8_t data);
void Coordinate_S_Process(void);
void Coordinate_M_Process(void);
void Target_Operate(uint8_t a, uint8_t b, uint8_t x, uint8_t y, uint8_t mode);
void Water_Pump_Start(void);
void Water_Pump_Stop(void);
void Water(void);
void Gun_Start(void);
void Gun_Stop(void);
void Seed(void);
void Seed_Water(void);
void Single_Seed(void);
void Single_Water(void);
void Multi_Seed(void);
void Multi_Water(void);
void Overall_Operate_Path(uint8_t mode);


#endif
