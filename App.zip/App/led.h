#ifndef _LED_H
#define _LED_H

#include "sys.h"

#define LED(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, GPIO_PIN_RESET); \
                  }while(0)       /* DRIVER_X */


void LED_Init(void);


#endif
