#ifndef _XYZ_MOVE_H
#define _XYZ_MOVE_H

#include "usart3.h"
#include "sys.h"
#include "driver.h"
#include "timer.h"
#include "delay.h"
#include "flash.h"

#define FLASH_SAVE_ADDR  0X08010000
#define X_R 1
#define X_L 2
#define Y_F 3
#define Y_B 4
#define Z_UP 5
#define Z_DOWN 6
#define STOP 7

extern uint8_t Target_X; 
extern uint8_t Target_Y; 
extern uint8_t Current_X; 
extern uint8_t Current_Y;
extern uint16_t Place_Flag;
extern uint8_t current_place;
extern uint8_t next_place;
extern uint8_t next_x;
extern uint8_t next_y;
static uint32_t place[];

void XYZ_Move(uint8_t direction, uint16_t pulse);
void Grid_X_Move(uint8_t direction, int num);
void Grid_Y_Move(uint8_t direction, int num);


#endif



