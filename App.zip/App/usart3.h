#ifndef _USART3_H
#define _USART3_H

// B10--U3(TX)  B11 -- U3(RX)

#include "sys.h"
#include "stdarg.h"	 	 
#include "stdio.h"	 	 
#include "string.h"	
#include "operate.h"
#include "led.h"

static uint8_t  n_i;
extern uint8_t  USART3_RX_BUFF[255];
extern uint8_t  USART3_TX_BUFF[255];
extern uint8_t  Mode_Flag;
extern UART_HandleTypeDef UART3_Handler; 

#define U3RXBUFFERSIZE   1 
extern uint8_t u3RxBuffer[U3RXBUFFERSIZE];

void u3_printf(char* fmt,...);
void Usart3_Init(uint32_t bound);
void Data_Process(void);

#endif
