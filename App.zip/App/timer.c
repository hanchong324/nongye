#include "timer.h"

//TIM4  ch1 X      PB6 
//TIM4  ch2 Y      PB7
//TIM4  ch3 Z      PB8
//TIM3  ch3 播种   PB0
//TIM3  ch4 浇水   PB1

TIM_HandleTypeDef TIM3_Handler;
TIM_HandleTypeDef TIM4_Handler;


TIM_OC_InitTypeDef TIM3_CH3_Handler;
TIM_OC_InitTypeDef TIM3_CH4_Handler;
TIM_OC_InitTypeDef TIM4_CH1_Handler;
TIM_OC_InitTypeDef TIM4_CH2_Handler;
TIM_OC_InitTypeDef TIM4_CH3_Handler;


void TIM_Init(void)
{
    TIM3_PWM_Init(1000-1,240-1);
    TIM4_PWM_Init(1000-1,240-1);

    SetCompare(X_PWM,0);
    SetCompare(Y_PWM,0);
    SetCompare(Z_PWM,0);
    SetCompare(SEED_PWM,0);
    SetCompare(WATER_PWM,0);

    delay_ms(300);
}



void TIM3_PWM_Init(uint16_t arr, uint16_t psc)     
{
    TIM3_Handler.Instance = TIM3;
    TIM3_Handler.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    TIM3_Handler.Init.Period = arr;
    TIM3_Handler.Init.Prescaler = psc;
    TIM3_Handler.Init.CounterMode = TIM_COUNTERMODE_UP;
    HAL_TIM_PWM_Init(&TIM3_Handler);

    TIM3_CH3_Handler.OCMode = TIM_OCMODE_PWM1;
    TIM3_CH3_Handler.Pulse = arr / 2;
    TIM3_CH3_Handler.OCPolarity = TIM_OCPOLARITY_HIGH;
    HAL_TIM_PWM_ConfigChannel(&TIM3_Handler,&TIM3_CH3_Handler,TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&TIM3_Handler,TIM_CHANNEL_2);

    TIM3_CH3_Handler.OCMode = TIM_OCMODE_PWM1;
    TIM3_CH3_Handler.Pulse = arr / 2;
    TIM3_CH3_Handler.OCPolarity = TIM_OCPOLARITY_HIGH;
    HAL_TIM_PWM_ConfigChannel(&TIM3_Handler,&TIM3_CH3_Handler,TIM_CHANNEL_4);
}

void TIM4_PWM_Init(uint16_t arr, uint16_t psc)     //CH1,A7
{
    TIM4_Handler.Instance = TIM4;
    TIM4_Handler.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    TIM4_Handler.Init.Period = arr;
    TIM4_Handler.Init.Prescaler = psc;
    TIM4_Handler.Init.CounterMode = TIM_COUNTERMODE_UP;
    HAL_TIM_PWM_Init(&TIM4_Handler);

    TIM4_CH1_Handler.OCMode = TIM_OCMODE_PWM1;
    TIM4_CH1_Handler.Pulse = arr / 2;
    TIM4_CH1_Handler.OCPolarity = TIM_OCPOLARITY_HIGH;
    HAL_TIM_PWM_ConfigChannel(&TIM4_Handler,&TIM4_CH1_Handler,TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&TIM4_Handler,TIM_CHANNEL_1);

    TIM4_CH2_Handler.OCMode = TIM_OCMODE_PWM1;
    TIM4_CH2_Handler.Pulse = arr / 2;
    TIM4_CH2_Handler.OCPolarity = TIM_OCPOLARITY_HIGH;
    HAL_TIM_PWM_ConfigChannel(&TIM4_Handler,&TIM4_CH2_Handler,TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&TIM4_Handler,TIM_CHANNEL_2);

    TIM4_CH1_Handler.OCMode = TIM_OCMODE_PWM1;
    TIM4_CH1_Handler.Pulse = arr / 2;
    TIM4_CH1_Handler.OCPolarity = TIM_OCPOLARITY_HIGH;
    HAL_TIM_PWM_ConfigChannel(&TIM4_Handler,&TIM4_CH3_Handler,TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&TIM4_Handler,TIM_CHANNEL_3);
}

void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim)
{
    __HAL_RCC_TIM3_CLK_ENABLE();
    __HAL_RCC_TIM4_CLK_ENABLE();

    __HAL_RCC_GPIOB_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct;

    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM3;
    HAL_GPIO_Init(GPIOB,&GPIO_InitStruct);

    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pin = GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM4;
    HAL_GPIO_Init(GPIOB,&GPIO_InitStruct);
}


//pwm = 1--X  2--Y 3--Z 4--SEED 5--WATER
void SetCompare(uint8_t pwm, uint32_t compare)  
{
    switch(pwm)
    {
       case 4:
       {
            TIM3->CCR3 = compare;
            break;
       }
       case 5:
       {
            TIM3->CCR4 = compare;
            break;
       }
       case 1:
       {
            TIM4->CCR1 = compare;
            break;
       }
       case 2:
       {
            TIM4->CCR2 = compare;
            break;
       }
       case 3:
       {
            TIM4->CCR3 = compare;
            break;
       }
    }
}


