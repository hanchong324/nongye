#include "operate.h"

uint8_t Place_Array[16];          //存储多目标点位置，Place_Array[i]=1则i为目标点位置
uint8_t Place_Axis_X[15] = {0};   //目标点X
uint8_t Place_Axis_Y[15] = {0};   //目标点Y
uint8_t Target_Num;               //目标点计数
uint8_t Place_Axis_BUF[15];

_Bool ROW1_FLAG = 0;
_Bool ROW2_FLAG = 0;
_Bool ROW3_FLAG = 0;


void Mode_Operate_Process(uint8_t data)
{
    switch (data)
    {        
        case 0x11:       //X轴移动测试
        {			
            Grid_X_Move(X_L,1);
            //delay_ms(200);
            break;
        }
        case 0x12:       //X轴移动测试
        {
            Grid_X_Move(X_R,1);
            //delay_ms(200);
            break;
        }
        case 0x13:       //Y轴移动测试
        {
            Grid_Y_Move(Y_F,1);
            delay_ms(200);
            break;
        }
        case 0x14:       //Y轴移动测试
        {
            Grid_Y_Move(Y_B,1);
            delay_ms(200);
            break;
        }
        case 0x15:       //Z轴移动测试
        {
            XYZ_Move(Z_UP,200);
            delay_ms(200);
            break;
        }
        case 0x16:       //Z轴移动测试
        {
            XYZ_Move(Z_DOWN,200);
            delay_ms(200);
            break;
        }
        case 0x17:         //回到起点
        {
            Target_Operate(Current_X,Current_Y,1,1,0);
            break;
        }
        case 0x21:
        {
            Overall_Operate_Path(1);
            break;
        }
        case 0x22:
        {
            Single_Seed();
            break;
        }
        case 0x23:
        {
            Multi_Seed();
            break;
        }
        case 0x31:
        {
            Overall_Operate_Path(2);
            break;
        }
        case 0x32:
        {
            Single_Water();
            break;
        }
        case 0x33:
        {
            Multi_Water();
            break;
        }

        default:
            break;
    }
    place[0] = Current_X;
    place[1] = Current_Y;
    Stmflash_Write(FLASH_SAVE_ADDR, place, 2);
}

void Coordinate_S_Process(void)
{
    Target_X = USART3_RX_BUFF[1];
    Target_Y = USART3_RX_BUFF[2];
    printf("T_X = %d\r\n",Target_X);
    printf("T_Y = %d\r\n",Target_Y);
}

void Coordinate_M_Process(void)
{
    uint8_t data1,data2;
    uint8_t i,j,temp;
    uint8_t row1 = 0;
    uint8_t row2 = 0;
    Target_Num = 0;
    data1 = USART3_RX_BUFF[1];
    data2 = USART3_RX_BUFF[2];
    printf("data1 = %#x\r\n",data1);
    printf("data2 = %#x\r\n",data2);
    
    for(i=0;i<8;i++)
    {
        Place_Array[i] = (data1>>i)&1;
    }
    for(i=0;i<8;i++)
    {
        Place_Array[i+8] = (data2>>i)&1;
    }
    for(i=15;i>0;i--)
    {        
        if(Place_Array[i])
        {   
            if((16-i) % 5 != 0)  
            {
                Place_Axis_X[Target_Num] = (16 - i) / 5 + 1;
                Place_Axis_Y[Target_Num] = (16 - i) % 5;
            }
            else
            {
                Place_Axis_X[Target_Num] = (16 - i) / 5;
                Place_Axis_Y[Target_Num] = 5;
            }
            if(Place_Axis_X[Target_Num] == 1)
            {
                row1++;
            }
            if(Place_Axis_X[Target_Num] == 2)
            {
                row2++;
            }
            Target_Num++;
        }
    }
    printf("row1 = %d,row2 = %d\r\n",row1,row2);
    for(i=row1;i<row2;i++)
    {
        for(j=i+1;j<row2+1;j++)
        {
            if(Place_Axis_Y[i] < Place_Axis_Y[j])
            {
                temp = Place_Axis_Y[i];
                Place_Axis_Y[i] = Place_Axis_Y[j];
                Place_Axis_Y[j] = temp;
            }
        }
    }
    for(i=0;i<Target_Num;i++)
    {
        Place_Axis_Y[Target_Num] = Place_Axis_BUF[Target_Num];
        printf("X = %d, Y = %d\r\n",Place_Axis_X[i],Place_Axis_Y[i]);
    }
}

void Water_Pump_Start(void)
{
    SetCompare(WATER_PWM,800);
}

void Water_Pump_Stop(void)
{
    SetCompare(WATER_PWM,0);
}

void Water(void)
{
    SetCompare(2,1900);  //45
    Water_Pump_Start();
    delay_ms(2000);
    Water_Pump_Stop();           //90
    SetCompare(2,1850);
    delay_ms(500);
}

void Gun_Start(void)
{
    SetCompare(SEED_PWM,550);
}

void Gun_Stop(void)
{
    SetCompare(SEED_PWM,0);
}

void Seed(void)
{
    XYZ_Move(Z_DOWN,200);
    delay_ms(600);
    XYZ_Move(STOP,0);
    delay_ms(500);
}

void Seed_Water(void)
{
    SetCompare(2,1850);
    XYZ_Move(Z_DOWN,200);
    delay_ms(600);
    XYZ_Move(STOP,0);
    delay_ms(500);
    Gun_Start();
    delay_ms(165);
    Gun_Stop();
    XYZ_Move(Z_UP,200);
    delay_ms(600);
    XYZ_Move(STOP,0);
    delay_ms(500);

    XYZ_Move(Y_B,200);
	delay_ms(500);
	XYZ_Move(STOP,0);
	delay_ms(500);
	SetCompare(2,1950);//0
	Water_Pump_Start();
	delay_ms(2000);
	Water_Pump_Stop();
	SetCompare(2,1850);//90
	delay_ms(300);
	XYZ_Move(Y_F,200);
	delay_ms(500);
	XYZ_Move(STOP,0);
	delay_ms(500);
}

// (a,b)为当前坐标,(x,y)为目标点坐标
//mode：操作模式   0:仅移动;1:seed;2:water;3:seed and water
void Target_Operate(uint8_t a, uint8_t b, uint8_t x, uint8_t y, uint8_t mode)  
{
    int num_x, num_y;

    Target_X = x;
    Target_Y = y;

    num_x = Target_X - a;
    num_y = Target_Y - b;

    if(num_x < 0)
    {
        num_x = - num_x;
        Grid_X_Move(X_L,num_x);
    }
    else if(num_x >= 0)
    {
        Grid_X_Move(X_R,num_x);
    }
    if(num_y < 0)
    {
        num_y = - num_y;
        Grid_Y_Move(Y_B,num_y);
    }
    else if(num_y >= 0)
    {
        Grid_Y_Move(Y_F,num_y);
    }
    switch(mode)
    {
        case 0:
        {
            break;
        }
        case 1:
        {
            Seed();
            break;
        }
        case 2:
        {
            Water();
            break;
        }
        case 3:
        {
            Seed_Water();
            break;
        }
    }
}

void Single_Seed(void)
{
    Target_Operate(Current_X, Current_Y, Target_X, Target_Y,SEED);    
}

void Single_Water(void)
{
    Target_Operate(Current_X, Current_Y, Target_X, Target_Y,WATER);  
}

void Multi_Seed(void)
{
    uint8_t i;
    for(i=0;i<Target_Num;i++)
    {
        Target_Operate(Current_X, Current_Y,Place_Axis_X[i], Place_Axis_Y[i],SEED);        
    }
    memset(Place_Axis_X, 0, 15);
    memset(Place_Axis_Y, 0, 15);
}
   

void Multi_Water(void)
{
        uint8_t i;
    for(i=0;i<Target_Num;i++)
    {
        Target_Operate(Current_X, Current_Y,Place_Axis_X[i], Place_Axis_Y[i],WATER);        
    }
    memset(Place_Axis_X, 0, 15);
    memset(Place_Axis_Y, 0, 15);
}

void Overall_Operate_Path(uint8_t mode) //mode：操作模式   0:仅移动;1:seed;2:water;3:seed and water
{
    uint8_t i;
    uint8_t Move_Row_Flag;
    Move_Row_Flag = Current_X;
    switch(Move_Row_Flag)
    {
        case 0: break;
        case 1:
        {
          if(!ROW1_FLAG)
            {
                switch(Current_Y)
                {                    
                    case 1:
                    {
                        while(Current_Y < 5)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,Current_Y + 1,mode);                        
                        }    
                        break;
                    }
                    case 2:
                    {
                        Target_Operate(Current_X,Current_Y,Move_Row_Flag,1,mode);
                        for(i=3;i<6;i++)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }                
                        break;
                    }
                    case 3:
                    {
                        for(i=4;i<6;i++)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }    
                        for(i=2;i>0;i--)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }     
                        break;
                    } 
                    case 4:
                    {
                        Target_Operate(Current_X,Current_Y,Move_Row_Flag,5,mode);
                        for(i=3;i>0;i--)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }           
                        break;
                    } 
                    case 5:
                    {
                        while(Current_Y > 1)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,Current_Y - 1,mode);
                        }   
                        break;
                    }  
                }
                ROW1_FLAG = 1;
            }
            if(ROW1_FLAG == 1 & ROW2_FLAG == 1 & ROW2_FLAG == 1)
            {
                Move_Row_Flag = 0;
            }
            else
            {
                Move_Row_Flag = 2;    
            }        
            break;
        }
        case 2:
        {
            if(!ROW2_FLAG)
            {
                switch(Current_Y)
                {
                    case 1:
                    {
                        while(Current_Y < 5)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,Current_Y + 1,mode);                        
                        }    
                        break;
                    }
                    case 2:
                    {
                        Target_Operate(Current_X,Current_Y,Move_Row_Flag,1,mode);
                        for(i=3;i<6;i++)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }                
                        break;
                    }
                    case 3:
                    {
                        for(i=4;i<6;i++)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }    
                        for(i=2;i>0;i--)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }     
                        break;
                    } 
                    case 4:
                    {
                        Target_Operate(Current_X,Current_Y,Move_Row_Flag,5,mode);
                        for(i=3;i>0;i--)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }           
                        break;
                    } 
                    case 5:
                    {
                        while(Current_Y > 1)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,Current_Y - 1,mode);
                        }   
                        break;
                    }  
                }
                ROW2_FLAG = 1;
            }
            if(ROW1_FLAG == 1 & ROW2_FLAG == 1 & ROW2_FLAG == 1)
            {
                Move_Row_Flag = 0;
            }
            else
            {
                Move_Row_Flag = 3;    
            }                                
            break;
        }
        case 3:
        {
            if(!ROW3_FLAG)
            {
                switch(Current_Y)
                {
                    case 1:
                    {
                        while(Current_Y < 5)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,Current_Y + 1,mode);                        
                        }    
                        break;
                    }
                    case 2:
                    {
                        Target_Operate(Current_X,Current_Y,Move_Row_Flag,1,mode);
                        for(i=3;i<6;i++)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }                
                        break;
                    }
                    case 3:
                    {
                        for(i=4;i<6;i++)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }    
                        for(i=2;i>0;i--)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }     
                        break;
                    } 
                    case 4:
                    {
                        Target_Operate(Current_X,Current_Y,Move_Row_Flag,5,mode);
                        for(i=3;i>0;i--)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,i,mode);
                        }           
                        break;
                    } 
                    case 5:
                    {
                        while(Current_Y > 1)
                        {
                            Target_Operate(Current_X,Current_Y,Move_Row_Flag,Current_Y - 1,mode);
                        }   
                        break;
                    }  
                }
                ROW3_FLAG = 1;
            }
            if(ROW1_FLAG == 1 & ROW2_FLAG == 1 & ROW2_FLAG == 1)
            {
                Move_Row_Flag = 0;
            }
            else
            {
                Move_Row_Flag = 2;    
            }        
            break;
        }
    }   
}




