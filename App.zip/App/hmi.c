#include "hmi.h"


void Hmi_SendByte(uint8_t byte)
{
    uint8_t i;
    uint8_t B[1];
    B[0] = byte;
    for(i = 0; i < 3; i++)
    {
        if(B[0] != 0)
        {            
            HAL_UART_Transmit(&UART3_Handler,B,1,100);            
            while(__HAL_UART_GET_FLAG(&UART3_Handler,USART_FLAG_TXE) == RESET);
        }
        
    }
}

void Hmi_SendStr(char *buf)
{
    uint8_t i = 0;
    while(buf[i] != '\0')
    {
        HAL_UART_Transmit(&UART3_Handler,(uint8_t *)buf,1,100);
        while(__HAL_UART_GET_FLAG(&UART3_Handler,USART_FLAG_TXE) == RESET);
        i++;
    }
}

void Hmi_SendStart(void)
{
    delay_ms(200);
    Hmi_SendByte(0xff);
    delay_ms(200);
}




