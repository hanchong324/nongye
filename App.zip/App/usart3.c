#include "usart3.h"
#include "usart1.h"

//  PB11----RX   PB10---TX


static uint8_t n_i;
uint8_t  Data_BUF[4];
uint8_t  USART3_RX_BUFF[255];
uint8_t  USART3_TX_BUFF[255];
uint8_t  U3_RX_STA=0; 
uint8_t  Mode_Flag;
uint8_t  u3RxBuffer[U3RXBUFFERSIZE];

void u3_printf(char* fmt,...)  
{  
	uint16_t i; 
	va_list ap; 
	va_start(ap,fmt);
	vsprintf((char*)USART3_TX_BUFF,fmt,ap);
	va_end(ap);
	i=strlen((const char*)USART3_TX_BUFF);		
	HAL_UART_Transmit(&UART3_Handler,(uint8_t*)USART3_TX_BUFF,i,0xffff);
}

UART_HandleTypeDef UART3_Handler;

void Usart3_Init(uint32_t bound)
{
    UART3_Handler.Instance = USART3;
    UART3_Handler.Init.BaudRate = bound;
    UART3_Handler.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    UART3_Handler.Init.Mode = UART_MODE_TX_RX;
    UART3_Handler.Init.Parity = UART_PARITY_NONE;
    UART3_Handler.Init.StopBits = UART_STOPBITS_1;
    UART3_Handler.Init.WordLength = UART_WORDLENGTH_8B;
    HAL_UART_Init(&UART3_Handler);
	
    HAL_UART_Receive_IT(&UART3_Handler,(uint8_t *)u3RxBuffer, U3RXBUFFERSIZE);
}


void USART3_IRQHandler(void)
{
	uint32_t timeout=0;

	
	HAL_UART_IRQHandler(&UART3_Handler);	
	
	timeout=0;
    while (HAL_UART_GetState(&UART3_Handler) != HAL_UART_STATE_READY)
	{
	 timeout++;
     if(timeout>HAL_MAX_DELAY) break;		
	
	}
     
	timeout=0;
	while(HAL_UART_Receive_IT(&UART3_Handler, (uint8_t *)u3RxBuffer, U3RXBUFFERSIZE) != HAL_OK)
	{
	 timeout++; 
	 if(timeout>HAL_MAX_DELAY) break;	
	}
}

void Data_Process(void)
{
	if(USART3_RX_BUFF[0] == 0xA0)
	{
		Mode_Flag = 0;			
	}
	if(USART3_RX_BUFF[0] == 0xA1)
	{
		Mode_Flag = 1;			
	}
	if(USART3_RX_BUFF[0] == 0xA2)
	{
		Mode_Flag = 2;			
	}
	
		
}


