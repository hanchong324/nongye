#include "driver.h"

void Driver_Init(void)
{
    __HAL_RCC_GPIOD_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStrcut;
    GPIO_InitStrcut.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStrcut.Pin = GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3;
    GPIO_InitStrcut.Pull = GPIO_PULLUP;
    GPIO_InitStrcut.Speed = GPIO_SPEED_HIGH;
    HAL_GPIO_Init(GPIOD,&GPIO_InitStrcut);
}


