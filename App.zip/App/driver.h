#ifndef _DRIVERS_H
#define _DRIVERS_H

//电机驱动

#include "sys.h"


/******************************************************************************************/
/* 引脚定义 */

#define DRIVER_X_GPIO_PORT        GPIOD
#define DRIVER_X_GPIO_PIN         GPIO_PIN_1

#define DRIVER_Y_GPIO_PORT        GPIOD
#define DRIVER_Y_GPIO_PIN         GPIO_PIN_2

#define DRIVER_Z_GPIO_PORT        GPIOD
#define DRIVER_Z_GPIO_PIN         GPIO_PIN_3

/******************************************************************************************/

#define DRIVER_X(x)   do{ x ? \
                      HAL_GPIO_WritePin(DRIVER_X_GPIO_PORT, DRIVER_X_GPIO_PIN, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(DRIVER_X_GPIO_PORT, DRIVER_X_GPIO_PIN, GPIO_PIN_RESET); \
                  }while(0)       /* DRIVER_X */

#define DRIVER_Y(x)   do{ x ? \
                      HAL_GPIO_WritePin(DRIVER_Y_GPIO_PORT, DRIVER_Y_GPIO_PIN, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(DRIVER_Y_GPIO_PORT, DRIVER_Y_GPIO_PIN, GPIO_PIN_RESET); \
                  }while(0)       /* DRIVER_Y */

#define DRIVER_Z(x)   do{ x ? \
                      HAL_GPIO_WritePin(DRIVER_Z_GPIO_PORT, DRIVER_Z_GPIO_PIN, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(DRIVER_Z_GPIO_PORT, DRIVER_Z_GPIO_PIN, GPIO_PIN_RESET); \
                  }while(0)       /* DRIVER_Z */


void Driver_Init(void);



#endif


