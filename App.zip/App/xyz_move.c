#include "xyz_move.h"

#define X_R 1       //右
#define X_L 2       //左
#define Y_F 3  		//前
#define Y_B 4  		//后
#define Z_UP 5		//上
#define Z_DOWN 6    //下
#define STOP 7		//停

#define Grid_X_DELAY 2000   //x轴一个格子的延时
#define Grid_Y_DELAY 2000   //y轴一个格子的延时

uint8_t Target_X; //目标x
uint8_t Target_Y; //目标y
uint8_t Current_X; //电流x
uint8_t Current_Y; //电流y

uint8_t current_place = 1;//当前位置
uint8_t next_place = 1;//下一位位置
uint8_t next_x;//下一个x
uint8_t next_y;//下一个y





void XYZ_Move(uint8_t direction, uint16_t pulse)
{
    switch(direction)
    {
        case 1:
        {
            DRIVER_X(0);
            SetCompare(X_PWM,pulse);
            SetCompare(Y_PWM,0);
            SetCompare(Z_PWM,0);
            break;
        }
        case 2:
        {
            DRIVER_X(1);
            SetCompare(X_PWM,pulse);
            SetCompare(Y_PWM,0);
            SetCompare(Z_PWM,0);
            break;
        }
        case 3:
        {
            DRIVER_Y(1);
            SetCompare(X_PWM,0);
            SetCompare(Y_PWM,pulse);
            SetCompare(Z_PWM,0);
            break;
        }
        case 4:
        {
            DRIVER_Y(0);
            SetCompare(X_PWM,0);
            SetCompare(Y_PWM,pulse);
            SetCompare(Z_PWM,0);
            break;
        }
        case 5:
        {
            DRIVER_Z(1);
            SetCompare(X_PWM,0);
            SetCompare(Y_PWM,0);
            SetCompare(Z_PWM,pulse);
            break;
        }
        case 6:
        {
            DRIVER_Z(0);
            SetCompare(X_PWM,0);
            SetCompare(Y_PWM,0);
            SetCompare(Z_PWM,pulse);
            break;
        }
        case 7:
        {
            SetCompare(X_PWM,0);
            SetCompare(Y_PWM,0);
            SetCompare(Z_PWM,0);
            break;
        }
        default:
            break;
    }
}

void Grid_X_Move(uint8_t direction, int num)//网格X
{
    XYZ_Move(direction,200);
    delay_ms(num * Grid_X_DELAY);
    XYZ_Move(STOP,0);
    if(direction == X_R)
    {
        Current_X += num;
    }
    else if(direction == X_L) 
    {
        Current_X -= num;
    }
    printf("C_X=%d\r\n",Current_X);
}

void Grid_Y_Move(uint8_t direction, int num)//网格Y
{
    XYZ_Move(direction,200);
    delay_ms(num * Grid_Y_DELAY);
    XYZ_Move(STOP,0);
    if(direction == Y_F)
    {
        Current_Y += num;
    }
    else if(direction == Y_B)
    {
        Current_Y -= num;
    }
    printf("C_Y=%d\r\n",Current_Y);
}






