#ifndef _TIMER_H
#define _TIMER_H

#include "sys.h"
#include "delay.h"


#define X_PWM     1
#define Y_PWM     2
#define Z_PWM     3
#define SEED_PWM  4
#define WATER_PWM 5

void TIM_Init(void);
void TIM3_PWM_Init(uint16_t arr, uint16_t psc); 
void TIM4_PWM_Init(uint16_t arr, uint16_t psc); 
void SetCompare(uint8_t pwm, uint32_t compare);


#endif
