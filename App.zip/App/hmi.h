#ifndef _HMI_H
#define _HMI_H


#include "usart3.h"
#include "sys.h"
#include "delay.h"

void Hmi_SendByte(uint8_t byte);
void Hmi_SendStr(char *buf);
void Hmi_SendStart(void);



#endif
