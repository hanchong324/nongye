#ifndef	__MH_Sensor_H_
#define	__MH_Sensor_H_

void MH_Init(void);
uint16_t ReadMH_ADC(void);

#endif
