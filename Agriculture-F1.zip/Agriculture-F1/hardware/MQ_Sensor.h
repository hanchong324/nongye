#ifndef	__MQ_Sensor_H_
#define	__MQ_Sensor_H_

void MQ_Init(void);
uint16_t ReadMQ_ADC(void);

#endif
