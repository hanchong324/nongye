#ifndef	__HMI_H_
#define	__HMI_H_

extern uint8_t RX_Str[50],RX_index;

void HMI_SendString(char *cmd);
void HMI_Init(void);
void Action(void);

#endif
