#ifndef	__BH1750_H_
#define	__BH1750_H_

void I2C_Config(void);
void BH1750_Init(void);
uint16_t BH1750_ReadLight(void);

#endif
