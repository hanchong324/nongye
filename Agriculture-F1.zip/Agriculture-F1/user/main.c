#include "stm32f10x.h"

//网络协议层
#include "onenet.h"

//网络设备
#include "esp8266.h"

#include "delay.h"
#include "usart.h"
#include "dht11.h"
#include "MQ_Sensor.H"
#include "MH_Sensor.H"
#include "BH1750.H"
//#include "HMI.h"

#include <stdio.h>


#define ESP8266_ONENET_INFO		"AT+CIPSTART=\"TCP\",\"mqtts.heclouds.com\",1883\r\n"

uint8_t Air_Temp,Air_Humi,Soil_Temp,Soil_Humi;
float Lux,Air_Value;



void Refresh_Data(void){
	char buf[20];
	sprintf(buf, "Air_Temp=%d\r\n",Air_Temp);
	Usart_SendString(USART_DEBUG,(uint8_t*)buf,16);
	
	sprintf(buf, "Air_Humi=%d\r\n",Air_Humi);
	Usart_SendString(USART_DEBUG,(uint8_t*)buf,16);

	sprintf(buf, "%d\r\n",Soil_Humi);
	Usart_SendString(USART_DEBUG,(uint8_t*)buf,16);

	sprintf(buf, "Soil_Temp=%d\r\n",Soil_Temp);
	Usart_SendString(USART_DEBUG,(uint8_t*)buf,16);	
	
	sprintf(buf, "Lux=%.1f\r\n",Lux);
	Usart_SendString(USART_DEBUG,(uint8_t*)buf,16);	

	sprintf(buf, "Air_Value=%.1f\r\n",Air_Value);
	Usart_SendString(USART_DEBUG,(uint8_t*)buf,16);	
}

void Hardware_Init(void)
{
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//中断控制器分组设置

	Delay_Init();									//systick初始化
	
	Usart1_Init(115200);							//串口1，打印信息用
	
	Usart2_Init(115200);							//串口2，驱动ESP8266用
		
	MQ_Init();//空气质量
	
	MH_Init();//土壤
	
//	I2C_Config();
//	BH1750_Init();
	
//	HMI_Init();
	
	while(DHT11_Init())
	{
		Usart_SendString(USART_DEBUG,"DHT11 Error",16);
		DelayMs(1000);
	}
	
	Usart_SendString(USART_DEBUG,"Hardware init OK",16);	
	DelayMs(1000);
}



int main(void)
{

	unsigned short timeCount = 0;	//发送间隔变量
	
	Hardware_Init();				//初始化外围硬件
	Usart_SendString(USART_DEBUG,"Connect MQTTs Server...",16);	//	
	ESP8266_Init();					//初始化ESP8266

	Usart_SendString(USART_DEBUG,"Connect MQTTs Server...",16);
	while(ESP8266_SendCmd(ESP8266_ONENET_INFO, "CONNECT"))
		DelayXms(500);
	Usart_SendString(USART_DEBUG,"Connect MQTT Server Success",16);
	DelayXms(500);	
	
	Usart_SendString(USART_DEBUG,"Device login...",16);	
	
	while(OneNet_DevLink())			//接入OneNET
		DelayXms(500);
	
	
	while(1)
	{	
		if(++timeCount >= 100)									//发送间隔5s
		{
			DHT11_Read_Data(&Air_Temp,&Air_Humi);//读取数据
			
			Air_Value=ReadMQ_ADC()*3.3/4096;
			Soil_Humi=ReadMH_ADC()*3.3/4096;
			Lux=BH1750_ReadLight();
			OneNet_SendData();									//发送数据
			
			timeCount = 0;
			ESP8266_Clear();
//			Action();
//			Refresh_Data();
		}

	}

}

